﻿using BusinessLayer.Services;
using CommomLayer.Entities;
using PresentationLayer.Validations;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GastosUniversitarios.Forms
{
    public partial class UsuariosForm : Form
    {
        private UsuarioServices _usuarioServices;
        private UsuarioValidator _usuarioValidator;
        bool isEditing = false;
        public UsuariosForm()
        {
            InitializeComponent();
            _usuarioServices = new UsuarioServices();
            _usuarioValidator = new UsuarioValidator();
            LoadUsers();
        }

        public void LoadUsers()
        {
            dgvUsuarios.DataSource = _usuarioServices.GetAllUsuarios();
            dgvUsuarios.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void btnAgregarUsuario_Click(object sender, EventArgs e)
        {
            if (isEditing)
            {
                int IdUsuario = int.Parse(dgvUsuarios.CurrentRow.Cells[0].Value.ToString());
                string NombreUsuario = txtNombreUsuario.Text;
                string Apellido = txtApellido.Text;
                string Carnet = txtCarnet.Text;
                string Clave = txtContraseña.Text;

                Usuario usuarios = new Usuario();
                usuarios.IdUsuario = IdUsuario;
                usuarios.NombreUsuario = NombreUsuario;
                usuarios.Apellido = Apellido;
                usuarios.Carnet = Carnet;
                usuarios.Contraseña = Clave;



                _usuarioServices.UpdateUsuario(usuarios);
                MessageBox.Show("Usuario agregado exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

                LimpiarCampos();

            }
            else
            {
                string NombreUsuario = txtNombreUsuario.Text;
                string Apellido = txtApellido.Text;
                string Carnet = txtCarnet.Text;
                string Clave = txtContraseña.Text;

                Usuario usuarios = new Usuario();
                usuarios.NombreUsuario = NombreUsuario;
                usuarios.Apellido = Apellido;
                usuarios.Carnet = Carnet;
                usuarios.Contraseña = Clave;

                
                MessageBox.Show("Usuario agregado exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadUsers();
                LimpiarCampos();

                UsuarioValidator usuarioValidator = new UsuarioValidator();
                FluentValidation.Results.ValidationResult result = usuarioValidator.Validate(usuarios);
                if (!result.IsValid)
                {
                    DisplayValidationErrors(result);
                    MessageBox.Show("hOLA");
                    return;
                }
                else
                {
                    _usuarioServices.AddUsuario(usuarios);
                }
            }
        }

        private void DisplayValidationErrors(FluentValidation.Results.ValidationResult result)
        {
            ValidationErrorProvider.Clear();

            foreach (var error in result.Errors)
            {
                switch (error.PropertyName)
                {
                    case nameof(Usuario.NombreUsuario):
                        ValidationErrorProvider.SetError(txtNombreUsuario, error.ErrorMessage);
                        break;
                    case nameof(Usuario.Apellido):
                        ValidationErrorProvider.SetError(txtApellido, error.ErrorMessage);
                        break;
                    case nameof(Usuario.Carnet):
                        ValidationErrorProvider.SetError(txtCarnet, error.ErrorMessage);
                        break;
                    case nameof(Usuario.Contraseña):
                        ValidationErrorProvider.SetError(txtContraseña, error.ErrorMessage);
                        break;
                }
            }
        }
        private void LimpiarCampos()
        {
            txtNombreUsuario.Clear();
            txtApellido.Clear();
            txtCarnet.Clear();
            txtContraseña.Clear();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvUsuarios.SelectedRows.Count < 1)
            {
                MessageBox.Show("Selecciona una fila", "Cuidado hermano", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                var eliminar = new DialogResult();
                eliminar = MessageBox.Show("¿Estas Seguro?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (eliminar == DialogResult.Yes)
                {
                    int IdUser = int.Parse(dgvUsuarios.CurrentRow.Cells[0].Value.ToString());
                    _usuarioServices.DeleteUsuario(IdUser);
                    LoadUsers();
                }
            }
        }

        private void pbCerrar_Click(object sender, EventArgs e)
        {
            PrincipalForm principalForm = new PrincipalForm();
            this.Close();
            principalForm.Show();
        }

        private void pbMinimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pbCerrar_MouseHover(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(pbCerrar, "Cerrar Aplicacion");
        }

        private void pbMinimizar_MouseHover(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(pbMinimizar, "Minimizar aplicacion");
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (dgvUsuarios.SelectedRows.Count > 0)
            {
                txtNombreUsuario.Text = dgvUsuarios.CurrentRow.Cells[1].Value.ToString();
                txtApellido.Text = dgvUsuarios.CurrentRow.Cells[2].Value.ToString();
                txtCarnet.Text = dgvUsuarios.CurrentRow.Cells[3].Value.ToString();
                txtContraseña.Text = dgvUsuarios.CurrentRow.Cells[3].Value.ToString();

                isEditing = true;
            }
            else
            {
                MessageBox.Show("Debe seleccionar una fila para editar");
            }
        }
    }
}
