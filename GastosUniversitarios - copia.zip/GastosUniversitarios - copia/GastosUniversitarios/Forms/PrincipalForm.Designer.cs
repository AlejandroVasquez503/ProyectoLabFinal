﻿namespace GastosUniversitarios.Forms
{
    partial class PrincipalForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btnUsuarios = new Button();
            btnGastos = new Button();
            groupBox1 = new GroupBox();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            pbCerrar = new PictureBox();
            pbMinimizar = new PictureBox();
            toolTip1 = new ToolTip(components);
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbCerrar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbMinimizar).BeginInit();
            SuspendLayout();
            // 
            // btnUsuarios
            // 
            btnUsuarios.Cursor = Cursors.Hand;
            btnUsuarios.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btnUsuarios.Location = new Point(136, 191);
            btnUsuarios.Name = "btnUsuarios";
            btnUsuarios.Size = new Size(292, 73);
            btnUsuarios.TabIndex = 0;
            btnUsuarios.Text = "Añadir Estudiantes";
            btnUsuarios.UseVisualStyleBackColor = true;
            btnUsuarios.Click += btnUsuarios_Click;
            // 
            // btnGastos
            // 
            btnGastos.Cursor = Cursors.Hand;
            btnGastos.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btnGastos.Location = new Point(136, 288);
            btnGastos.Name = "btnGastos";
            btnGastos.Size = new Size(292, 73);
            btnGastos.TabIndex = 1;
            btnGastos.Text = "Gastos";
            btnGastos.UseVisualStyleBackColor = true;
            btnGastos.Click += btnGastos_Click;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.Control;
            groupBox1.Controls.Add(btnGastos);
            groupBox1.Controls.Add(btnUsuarios);
            groupBox1.Location = new Point(454, 51);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(570, 462);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Formulario";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.univo;
            pictureBox1.Location = new Point(60, 198);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(318, 213);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.BackColor = SystemColors.HotTrack;
            label1.Font = new Font("Century Gothic", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(0, 62);
            label1.Name = "label1";
            label1.Size = new Size(424, 78);
            label1.TabIndex = 4;
            label1.Text = "Control de gastos Universitarios";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pbCerrar
            // 
            pbCerrar.Cursor = Cursors.Hand;
            pbCerrar.Image = Properties.Resources.close_remove_delete_icon_148989;
            pbCerrar.Location = new Point(985, 12);
            pbCerrar.Name = "pbCerrar";
            pbCerrar.Size = new Size(39, 33);
            pbCerrar.SizeMode = PictureBoxSizeMode.Zoom;
            pbCerrar.TabIndex = 2;
            pbCerrar.TabStop = false;
            pbCerrar.Click += pbCerrar_Click;
            pbCerrar.MouseHover += pbCerrar_MouseHover;
            // 
            // pbMinimizar
            // 
            pbMinimizar.Cursor = Cursors.Hand;
            pbMinimizar.Image = Properties.Resources.negative_sign_icon_icons_com_70439;
            pbMinimizar.Location = new Point(940, 12);
            pbMinimizar.Name = "pbMinimizar";
            pbMinimizar.Size = new Size(39, 33);
            pbMinimizar.SizeMode = PictureBoxSizeMode.Zoom;
            pbMinimizar.TabIndex = 5;
            pbMinimizar.TabStop = false;
            pbMinimizar.Click += pbMinimizar_Click;
            pbMinimizar.MouseHover += pbMinimizar_MouseHover;
            // 
            // PrincipalForm
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1065, 557);
            Controls.Add(pbMinimizar);
            Controls.Add(pbCerrar);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Controls.Add(groupBox1);
            Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.None;
            Name = "PrincipalForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "PrincipalForm";
            groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbCerrar).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbMinimizar).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button btnUsuarios;
        private Button btnGastos;
        private GroupBox groupBox1;
        private PictureBox pictureBox1;
        private Label label1;
        private PictureBox pbCerrar;
        private PictureBox pbMinimizar;
        private ToolTip toolTip1;
    }
}