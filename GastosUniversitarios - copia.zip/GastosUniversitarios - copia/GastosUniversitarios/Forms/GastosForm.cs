﻿using BusinessLayer.Services;
using CommomLayer.Entities;
using PresentationLayer.Validations;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FluentValidation.Results;

namespace GastosUniversitarios.Forms
{
    public partial class GastosForm : Form
    {
        private GastoService _gastoService;
        private CategoriaService _categoriaService;
        private UsuarioServices _usuarioServices;
        bool isEditing = false;
        public GastosForm()
        {
            InitializeComponent();
            _gastoService = new GastoService();
            _categoriaService = new CategoriaService();
            _usuarioServices = new UsuarioServices();
            LoadFormData();
        }

        private void LoadGastos()
        {
            dgvGastos.DataSource = null;
            dgvGastos.DataSource = _gastoService.GetAllGastos();
            dgvGastos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;


            dgvGastos.ClearSelection();
        }


        private void LoadFormData()
        {
            CargarCategorias();
            CargarUsuarios();
            LoadGastos();
        }


        private void CargarCategorias()
        {
            var categorias = _categoriaService.GetAllCategorias();
            cmbCategoria.DataSource = categorias;
            cmbCategoria.DisplayMember = "NombreCategoria";
            cmbCategoria.ValueMember = "IdCategoria";
        }

        private void CargarUsuarios()
        {
            var usuarios = _usuarioServices.GetAllUsuarios();
            cmbUsuario.DataSource = usuarios;
            cmbUsuario.DisplayMember = "NombreUsuario";
            cmbUsuario.ValueMember = "IdUsuario";
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (isEditing)
            {
                int IdGastos = int.Parse(dgvGastos.CurrentRow.Cells[0].Value.ToString());
                DateTime fecha = DateTime.Now;
                decimal Monto = Convert.ToDecimal(txtMonto.Text);
                string Descripcion = txtDescripcion.Text;
                int Categoria = (int)cmbCategoria.SelectedValue;
                int Usuario = (int)cmbUsuario.SelectedValue;

                GastoUniversitario gastoUniversitario = new GastoUniversitario();
                gastoUniversitario.IdGasto = IdGastos;
                gastoUniversitario.Fecha = fecha;
                gastoUniversitario.Monto = Monto;
                gastoUniversitario.Descripcion = Descripcion;
                gastoUniversitario.IdCategoria = Categoria;
                gastoUniversitario.IdUsuario = Usuario;
     
                MessageBox.Show("Gasto agregado exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                _gastoService.UpdateGasto(gastoUniversitario);
                LoadGastos();
                CargarCategorias();
                CargarUsuarios();

            }
            else
            {
                Decimal Monto = Convert.ToDecimal(txtMonto.Text);
                string Descripcion = txtDescripcion.Text;
                int Categoria = (int)cmbCategoria.SelectedValue;
                int Usuario = (int)cmbUsuario.SelectedValue;

                GastoUniversitario gastoUniversitario = new GastoUniversitario();
                gastoUniversitario.Monto = Monto;
                gastoUniversitario.Descripcion = Descripcion;
                gastoUniversitario.IdCategoria = Categoria;
                gastoUniversitario.IdUsuario = Usuario;

                LoadGastos();
                GastosUniversitariosValidator gastosUniversitariosValidator = new GastosUniversitariosValidator();
                FluentValidation.Results.ValidationResult result = gastosUniversitariosValidator.Validate(gastoUniversitario);
                if (!result.IsValid)
                {
                    DisplayValidationErrors(result);
                    MessageBox.Show("Error");
                    return;
                }
                else
                {
                    _gastoService.AddGasto(gastoUniversitario);
                }
                
            }
        }

        private void DisplayValidationErrors(FluentValidation.Results.ValidationResult result)
        {
            ValidationErrorProvider.Clear();

            foreach (var error in result.Errors)
            {
                switch (error.PropertyName)
                {
                    case nameof(GastoUniversitario.Monto):
                        ValidationErrorProvider.SetError(txtMonto, error.ErrorMessage);
                        break;
                    case nameof(GastoUniversitario.Descripcion):
                        ValidationErrorProvider.SetError(txtDescripcion, error.ErrorMessage);
                        break;
                    case nameof(GastoUniversitario.IdCategoria):
                        ValidationErrorProvider.SetError(cmbCategoria, error.ErrorMessage);
                        break;
                    case nameof(GastoUniversitario.IdUsuario):
                        ValidationErrorProvider.SetError(cmbUsuario, error.ErrorMessage);
                        break;
                }
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (dgvGastos.SelectedRows.Count > 0)
            {
                cmbUsuario.Text = dgvGastos.CurrentRow.Cells[1].Value.ToString();
                txtMonto.Text = dgvGastos.CurrentRow.Cells[2].Value.ToString();
                txtDescripcion.Text = dgvGastos.CurrentRow.Cells[3].Value.ToString();
                cmbCategoria.Text = dgvGastos.CurrentRow.Cells[4].Value.ToString();
                txtFecha.Text = dgvGastos.CurrentRow.Cells[5].Value.ToString();


                isEditing = true;
            }
            else
            {
                MessageBox.Show("Debe seleccionar una fila para editar");
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvGastos.SelectedRows.Count < 1)
            {
                MessageBox.Show("Debe seleccionar una fila para eliminar", "Cuidado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                var EliminarConfirmar = new DialogResult();

                EliminarConfirmar = MessageBox.Show("Esta seguro que desea eliminar este usuario?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (EliminarConfirmar == DialogResult.Yes)
                {
                    int IdGastos = int.Parse(dgvGastos.CurrentRow.Cells[0].Value.ToString());
                    _gastoService.DeleteGasto(IdGastos);

                    LoadGastos();
                }
            }


        }

        private void pbCerrar_Click(object sender, EventArgs e)
        {
            PrincipalForm principalForm = new PrincipalForm();
            this.Close();
            principalForm.Show();
        }

        private void pbMinimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pbCerrar_MouseHover(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(pbCerrar, "Cerrar Aplicacion");
        }

        private void pbMinimizar_MouseHover(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(pbMinimizar, "Minizar Aplicacion");
        }
    }
}
