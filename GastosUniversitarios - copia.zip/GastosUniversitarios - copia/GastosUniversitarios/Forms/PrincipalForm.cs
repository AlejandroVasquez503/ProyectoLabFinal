﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GastosUniversitarios.Forms
{
    public partial class PrincipalForm : Form
    {
        public PrincipalForm()
        {
            InitializeComponent();
        }

        private void btnUsuarios_Click(object sender, EventArgs e)
        {
            UsuariosForm usuariosForm = new UsuariosForm();
            this.Hide();
            usuariosForm.Show();
        }

        private void btnGastos_Click(object sender, EventArgs e)
        {
            GastosForm gastosForm = new GastosForm();
            this.Hide();
            gastosForm.Show();
        }

        private void pbCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pbMinimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void pbCerrar_MouseHover(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(pbCerrar, "Cerrar Aplicacion");
        }

        private void pbMinimizar_MouseHover(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(pbMinimizar, "Minimizar Aplicacion");
        }
    }
}
