﻿namespace GastosUniversitarios.Forms
{
    partial class UsuariosForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            labelIngresarUsuarios = new Label();
            groupBoxUsuario = new GroupBox();
            pictureBox1 = new PictureBox();
            txtContraseña = new TextBox();
            btnEditar = new Button();
            btnDelete = new Button();
            txtCarnet = new TextBox();
            txtApellido = new TextBox();
            btnAgregarUsuario = new Button();
            txtNombreUsuario = new TextBox();
            labelContraseña = new Label();
            labelCarnet = new Label();
            labelLastName = new Label();
            labelName = new Label();
            dgvUsuarios = new DataGridView();
            pbMinimizar = new PictureBox();
            pbCerrar = new PictureBox();
            toolTip1 = new ToolTip(components);
            ValidationErrorProvider = new ErrorProvider(components);
            groupBoxUsuario.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvUsuarios).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbMinimizar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbCerrar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ValidationErrorProvider).BeginInit();
            SuspendLayout();
            // 
            // labelIngresarUsuarios
            // 
            labelIngresarUsuarios.BackColor = Color.Turquoise;
            labelIngresarUsuarios.Font = new Font("Segoe UI", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelIngresarUsuarios.ForeColor = Color.White;
            labelIngresarUsuarios.Location = new Point(0, 34);
            labelIngresarUsuarios.Name = "labelIngresarUsuarios";
            labelIngresarUsuarios.Size = new Size(488, 45);
            labelIngresarUsuarios.TabIndex = 0;
            labelIngresarUsuarios.Text = "Ingrese un Usuario";
            labelIngresarUsuarios.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // groupBoxUsuario
            // 
            groupBoxUsuario.BackColor = Color.White;
            groupBoxUsuario.Controls.Add(pictureBox1);
            groupBoxUsuario.Controls.Add(txtContraseña);
            groupBoxUsuario.Controls.Add(btnEditar);
            groupBoxUsuario.Controls.Add(btnDelete);
            groupBoxUsuario.Controls.Add(txtCarnet);
            groupBoxUsuario.Controls.Add(txtApellido);
            groupBoxUsuario.Controls.Add(btnAgregarUsuario);
            groupBoxUsuario.Controls.Add(txtNombreUsuario);
            groupBoxUsuario.Controls.Add(labelContraseña);
            groupBoxUsuario.Controls.Add(labelCarnet);
            groupBoxUsuario.Controls.Add(labelLastName);
            groupBoxUsuario.Controls.Add(labelName);
            groupBoxUsuario.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBoxUsuario.Location = new Point(32, 120);
            groupBoxUsuario.Name = "groupBoxUsuario";
            groupBoxUsuario.Size = new Size(485, 578);
            groupBoxUsuario.TabIndex = 1;
            groupBoxUsuario.TabStop = false;
            groupBoxUsuario.Text = "Formulario";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.univo;
            pictureBox1.Location = new Point(0, 497);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(112, 81);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            // 
            // txtContraseña
            // 
            txtContraseña.Location = new Point(25, 351);
            txtContraseña.Name = "txtContraseña";
            txtContraseña.PasswordChar = '*';
            txtContraseña.Size = new Size(352, 26);
            txtContraseña.TabIndex = 9;
            // 
            // btnEditar
            // 
            btnEditar.BackColor = Color.DodgerBlue;
            btnEditar.FlatStyle = FlatStyle.Flat;
            btnEditar.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnEditar.ForeColor = Color.White;
            btnEditar.Location = new Point(142, 417);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(105, 39);
            btnEditar.TabIndex = 5;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = false;
            btnEditar.Click += btnEditar_Click;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.Red;
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnDelete.ForeColor = Color.White;
            btnDelete.Location = new Point(272, 417);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(105, 39);
            btnDelete.TabIndex = 4;
            btnDelete.Text = "Eliminar";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // txtCarnet
            // 
            txtCarnet.Location = new Point(25, 267);
            txtCarnet.Name = "txtCarnet";
            txtCarnet.Size = new Size(352, 26);
            txtCarnet.TabIndex = 8;
            // 
            // txtApellido
            // 
            txtApellido.Location = new Point(25, 181);
            txtApellido.Name = "txtApellido";
            txtApellido.Size = new Size(352, 26);
            txtApellido.TabIndex = 7;
            // 
            // btnAgregarUsuario
            // 
            btnAgregarUsuario.BackColor = Color.DarkGreen;
            btnAgregarUsuario.FlatStyle = FlatStyle.Flat;
            btnAgregarUsuario.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnAgregarUsuario.ForeColor = Color.White;
            btnAgregarUsuario.Location = new Point(22, 417);
            btnAgregarUsuario.Name = "btnAgregarUsuario";
            btnAgregarUsuario.Size = new Size(105, 39);
            btnAgregarUsuario.TabIndex = 2;
            btnAgregarUsuario.Text = "Agregar";
            btnAgregarUsuario.UseVisualStyleBackColor = false;
            btnAgregarUsuario.Click += btnAgregarUsuario_Click;
            // 
            // txtNombreUsuario
            // 
            txtNombreUsuario.Location = new Point(25, 99);
            txtNombreUsuario.Name = "txtNombreUsuario";
            txtNombreUsuario.Size = new Size(352, 26);
            txtNombreUsuario.TabIndex = 6;
            // 
            // labelContraseña
            // 
            labelContraseña.AutoSize = true;
            labelContraseña.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelContraseña.Location = new Point(25, 307);
            labelContraseña.Name = "labelContraseña";
            labelContraseña.Size = new Size(102, 25);
            labelContraseña.TabIndex = 5;
            labelContraseña.Text = "Contraseña";
            // 
            // labelCarnet
            // 
            labelCarnet.AutoSize = true;
            labelCarnet.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelCarnet.Location = new Point(25, 220);
            labelCarnet.Name = "labelCarnet";
            labelCarnet.Size = new Size(65, 25);
            labelCarnet.TabIndex = 4;
            labelCarnet.Text = "Carnet";
            // 
            // labelLastName
            // 
            labelLastName.AutoSize = true;
            labelLastName.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelLastName.Location = new Point(25, 138);
            labelLastName.Name = "labelLastName";
            labelLastName.Size = new Size(77, 25);
            labelLastName.TabIndex = 3;
            labelLastName.Text = "Apellido";
            // 
            // labelName
            // 
            labelName.AutoSize = true;
            labelName.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelName.Location = new Point(25, 48);
            labelName.Name = "labelName";
            labelName.Size = new Size(76, 25);
            labelName.TabIndex = 2;
            labelName.Text = "Nombre";
            // 
            // dgvUsuarios
            // 
            dgvUsuarios.BackgroundColor = Color.White;
            dgvUsuarios.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvUsuarios.Location = new Point(548, 130);
            dgvUsuarios.Name = "dgvUsuarios";
            dgvUsuarios.RowHeadersWidth = 51;
            dgvUsuarios.Size = new Size(622, 568);
            dgvUsuarios.TabIndex = 3;
            // 
            // pbMinimizar
            // 
            pbMinimizar.Cursor = Cursors.Hand;
            pbMinimizar.Image = Properties.Resources.negative_sign_icon_icons_com_70439;
            pbMinimizar.Location = new Point(1086, 34);
            pbMinimizar.Name = "pbMinimizar";
            pbMinimizar.Size = new Size(39, 33);
            pbMinimizar.SizeMode = PictureBoxSizeMode.Zoom;
            pbMinimizar.TabIndex = 9;
            pbMinimizar.TabStop = false;
            pbMinimizar.Click += pbMinimizar_Click;
            pbMinimizar.MouseHover += pbMinimizar_MouseHover;
            // 
            // pbCerrar
            // 
            pbCerrar.Cursor = Cursors.Hand;
            pbCerrar.Image = Properties.Resources.close_remove_delete_icon_148989;
            pbCerrar.Location = new Point(1131, 34);
            pbCerrar.Name = "pbCerrar";
            pbCerrar.Size = new Size(39, 33);
            pbCerrar.SizeMode = PictureBoxSizeMode.Zoom;
            pbCerrar.TabIndex = 8;
            pbCerrar.TabStop = false;
            pbCerrar.Click += pbCerrar_Click;
            pbCerrar.MouseHover += pbCerrar_MouseHover;
            // 
            // ValidationErrorProvider
            // 
            ValidationErrorProvider.ContainerControl = this;
            // 
            // UsuariosForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1191, 746);
            Controls.Add(pbMinimizar);
            Controls.Add(pbCerrar);
            Controls.Add(dgvUsuarios);
            Controls.Add(groupBoxUsuario);
            Controls.Add(labelIngresarUsuarios);
            FormBorderStyle = FormBorderStyle.None;
            Name = "UsuariosForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "MainForm";
            groupBoxUsuario.ResumeLayout(false);
            groupBoxUsuario.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvUsuarios).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbMinimizar).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbCerrar).EndInit();
            ((System.ComponentModel.ISupportInitialize)ValidationErrorProvider).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label labelIngresarUsuarios;
        private GroupBox groupBoxUsuario;
        private Label labelContraseña;
        private Label labelCarnet;
        private Label labelLastName;
        private Label labelName;
        private TextBox txtContraseña;
        private TextBox txtCarnet;
        private TextBox txtApellido;
        private TextBox txtNombreUsuario;
        private Button btnAgregarUsuario;
        private DataGridView dgvUsuarios;
        private Button btnDelete;
        private Button btnEditar;
        private PictureBox pbMinimizar;
        private PictureBox pbCerrar;
        private ToolTip toolTip1;
        private PictureBox pictureBox1;
        private ErrorProvider ValidationErrorProvider;
    }
}