﻿namespace GastosUniversitarios.Forms
{
    partial class GastosForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            labelEditarGastos = new Label();
            labelMonto = new Label();
            groupBox1 = new GroupBox();
            btnEliminar = new Button();
            pictureBox1 = new PictureBox();
            txtFecha = new TextBox();
            labelFecha = new Label();
            btnEditar = new Button();
            txtDescripcion = new TextBox();
            btnAgregar = new Button();
            labelDescripción = new Label();
            labelUsuario = new Label();
            txtMonto = new TextBox();
            cmbUsuario = new ComboBox();
            cmbCategoria = new ComboBox();
            labelCategoria = new Label();
            dgvGastos = new DataGridView();
            pbMinimizar = new PictureBox();
            pbCerrar = new PictureBox();
            toolTip1 = new ToolTip(components);
            ValidationErrorProvider = new ErrorProvider(components);
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvGastos).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbMinimizar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbCerrar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ValidationErrorProvider).BeginInit();
            SuspendLayout();
            // 
            // labelEditarGastos
            // 
            labelEditarGastos.BackColor = Color.LimeGreen;
            labelEditarGastos.Font = new Font("Segoe UI", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelEditarGastos.ForeColor = Color.White;
            labelEditarGastos.Location = new Point(67, 24);
            labelEditarGastos.Name = "labelEditarGastos";
            labelEditarGastos.Size = new Size(637, 43);
            labelEditarGastos.TabIndex = 0;
            labelEditarGastos.Text = "Editar Gastos";
            labelEditarGastos.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labelMonto
            // 
            labelMonto.AutoSize = true;
            labelMonto.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelMonto.Location = new Point(50, 143);
            labelMonto.Name = "labelMonto";
            labelMonto.Size = new Size(63, 25);
            labelMonto.TabIndex = 1;
            labelMonto.Text = "Monto";
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.White;
            groupBox1.Controls.Add(btnEliminar);
            groupBox1.Controls.Add(pictureBox1);
            groupBox1.Controls.Add(txtFecha);
            groupBox1.Controls.Add(labelFecha);
            groupBox1.Controls.Add(btnEditar);
            groupBox1.Controls.Add(txtDescripcion);
            groupBox1.Controls.Add(btnAgregar);
            groupBox1.Controls.Add(labelDescripción);
            groupBox1.Controls.Add(labelUsuario);
            groupBox1.Controls.Add(txtMonto);
            groupBox1.Controls.Add(cmbUsuario);
            groupBox1.Controls.Add(labelMonto);
            groupBox1.Controls.Add(cmbCategoria);
            groupBox1.Controls.Add(labelCategoria);
            groupBox1.Location = new Point(67, 87);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(1067, 285);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Ingrese los datos";
            // 
            // btnEliminar
            // 
            btnEliminar.BackColor = Color.Red;
            btnEliminar.FlatStyle = FlatStyle.Flat;
            btnEliminar.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnEliminar.ForeColor = Color.White;
            btnEliminar.Location = new Point(910, 224);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(128, 43);
            btnEliminar.TabIndex = 13;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = false;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.univo;
            pictureBox1.Location = new Point(955, 9);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(106, 72);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 17;
            pictureBox1.TabStop = false;
            // 
            // txtFecha
            // 
            txtFecha.Enabled = false;
            txtFecha.Location = new Point(663, 87);
            txtFecha.Name = "txtFecha";
            txtFecha.Size = new Size(398, 26);
            txtFecha.TabIndex = 10;
            // 
            // labelFecha
            // 
            labelFecha.AutoSize = true;
            labelFecha.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelFecha.Location = new Point(586, 86);
            labelFecha.Name = "labelFecha";
            labelFecha.Size = new Size(58, 25);
            labelFecha.TabIndex = 9;
            labelFecha.Text = "Fecha";
            // 
            // btnEditar
            // 
            btnEditar.BackColor = Color.DodgerBlue;
            btnEditar.FlatStyle = FlatStyle.Flat;
            btnEditar.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnEditar.ForeColor = Color.White;
            btnEditar.Location = new Point(760, 224);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(124, 43);
            btnEditar.TabIndex = 12;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = false;
            btnEditar.Click += btnEditar_Click;
            // 
            // txtDescripcion
            // 
            txtDescripcion.Location = new Point(132, 212);
            txtDescripcion.Name = "txtDescripcion";
            txtDescripcion.Size = new Size(398, 26);
            txtDescripcion.TabIndex = 8;
            // 
            // btnAgregar
            // 
            btnAgregar.BackColor = Color.DarkGreen;
            btnAgregar.FlatStyle = FlatStyle.Flat;
            btnAgregar.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            btnAgregar.ForeColor = Color.White;
            btnAgregar.Location = new Point(610, 224);
            btnAgregar.Name = "btnAgregar";
            btnAgregar.Size = new Size(126, 43);
            btnAgregar.TabIndex = 11;
            btnAgregar.Text = "Agregar";
            btnAgregar.UseVisualStyleBackColor = false;
            btnAgregar.Click += btnAgregar_Click;
            // 
            // labelDescripción
            // 
            labelDescripción.AutoSize = true;
            labelDescripción.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelDescripción.Location = new Point(10, 211);
            labelDescripción.Name = "labelDescripción";
            labelDescripción.Size = new Size(103, 25);
            labelDescripción.TabIndex = 7;
            labelDescripción.Text = "Descripción";
            // 
            // labelUsuario
            // 
            labelUsuario.AutoSize = true;
            labelUsuario.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelUsuario.Location = new Point(39, 85);
            labelUsuario.Name = "labelUsuario";
            labelUsuario.Size = new Size(72, 25);
            labelUsuario.TabIndex = 6;
            labelUsuario.Text = "Usuario";
            // 
            // txtMonto
            // 
            txtMonto.Location = new Point(132, 144);
            txtMonto.Name = "txtMonto";
            txtMonto.Size = new Size(398, 26);
            txtMonto.TabIndex = 2;
            // 
            // cmbUsuario
            // 
            cmbUsuario.FormattingEnabled = true;
            cmbUsuario.Location = new Point(132, 82);
            cmbUsuario.Name = "cmbUsuario";
            cmbUsuario.Size = new Size(398, 28);
            cmbUsuario.TabIndex = 5;
            // 
            // cmbCategoria
            // 
            cmbCategoria.FormattingEnabled = true;
            cmbCategoria.Location = new Point(663, 156);
            cmbCategoria.Name = "cmbCategoria";
            cmbCategoria.Size = new Size(398, 28);
            cmbCategoria.TabIndex = 4;
            // 
            // labelCategoria
            // 
            labelCategoria.AutoSize = true;
            labelCategoria.Font = new Font("Segoe UI", 10.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            labelCategoria.Location = new Point(554, 156);
            labelCategoria.Name = "labelCategoria";
            labelCategoria.Size = new Size(90, 25);
            labelCategoria.TabIndex = 3;
            labelCategoria.Text = "Categoria";
            // 
            // dgvGastos
            // 
            dgvGastos.BackgroundColor = Color.White;
            dgvGastos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvGastos.Location = new Point(67, 378);
            dgvGastos.Name = "dgvGastos";
            dgvGastos.RowHeadersWidth = 51;
            dgvGastos.Size = new Size(1067, 353);
            dgvGastos.TabIndex = 14;
            // 
            // pbMinimizar
            // 
            pbMinimizar.Cursor = Cursors.Hand;
            pbMinimizar.Image = Properties.Resources.negative_sign_icon_icons_com_70439;
            pbMinimizar.Location = new Point(1095, 12);
            pbMinimizar.Name = "pbMinimizar";
            pbMinimizar.Size = new Size(39, 33);
            pbMinimizar.SizeMode = PictureBoxSizeMode.Zoom;
            pbMinimizar.TabIndex = 16;
            pbMinimizar.TabStop = false;
            pbMinimizar.Click += pbMinimizar_Click;
            pbMinimizar.MouseHover += pbMinimizar_MouseHover;
            // 
            // pbCerrar
            // 
            pbCerrar.Cursor = Cursors.Hand;
            pbCerrar.Image = Properties.Resources.close_remove_delete_icon_148989;
            pbCerrar.Location = new Point(1140, 12);
            pbCerrar.Name = "pbCerrar";
            pbCerrar.Size = new Size(39, 33);
            pbCerrar.SizeMode = PictureBoxSizeMode.Zoom;
            pbCerrar.TabIndex = 15;
            pbCerrar.TabStop = false;
            pbCerrar.Click += pbCerrar_Click;
            pbCerrar.MouseHover += pbCerrar_MouseHover;
            // 
            // ValidationErrorProvider
            // 
            ValidationErrorProvider.ContainerControl = this;
            // 
            // GastosForm
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1191, 746);
            Controls.Add(pbMinimizar);
            Controls.Add(pbCerrar);
            Controls.Add(dgvGastos);
            Controls.Add(labelEditarGastos);
            Controls.Add(groupBox1);
            Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.None;
            Name = "GastosForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "GastosForm";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvGastos).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbMinimizar).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbCerrar).EndInit();
            ((System.ComponentModel.ISupportInitialize)ValidationErrorProvider).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label labelEditarGastos;
        private Label labelMonto;
        private GroupBox groupBox1;
        private TextBox txtDescripcion;
        private Label labelDescripción;
        private Label labelUsuario;
        private ComboBox cmbUsuario;
        private ComboBox cmbCategoria;
        private Label labelCategoria;
        private TextBox txtMonto;
        private Button btnAgregar;
        private Button btnEditar;
        private Button btnEliminar;
        private DataGridView dgvGastos;
        private PictureBox pbMinimizar;
        private PictureBox pbCerrar;
        private ToolTip toolTip1;
        private PictureBox pictureBox1;
        private TextBox txtFecha;
        private Label labelFecha;
        private ErrorProvider ValidationErrorProvider;
    }
}