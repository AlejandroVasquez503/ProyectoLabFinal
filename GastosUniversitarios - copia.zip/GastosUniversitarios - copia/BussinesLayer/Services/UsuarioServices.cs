﻿using CommomLayer;
using CommomLayer.Entities;
using DataAccessLayer;
using DataAccessLayer.Repositories;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Services
{
    public class UsuarioServices
    {
        private UsuarioRepository _usuarioRepository;
        public UsuarioServices()
        {
            _usuarioRepository = new UsuarioRepository();
        }

        public DataTable GetAllUsuarios()
        {
            return _usuarioRepository.GetAllUsuarios(); 
        }



        public void AddUsuario(Usuario usuario)
        {
            _usuarioRepository.InsertUsuario(usuario);
        }

        public void UpdateUsuario(Usuario usuario)
        {
            _usuarioRepository.UpdateUsuario(usuario);
        }

        public void DeleteUsuario(int id)
        {
            _usuarioRepository.DeleteUsuario(id);
        }
    }
}
