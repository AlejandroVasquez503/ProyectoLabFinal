﻿using CommomLayer.Entities;
using DataAccessLayer.DbConnection;
using DataAccessLayer.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Services
{
    public class CategoriaService
    {
        private  CategoriaGastoRepository _categoriaGastoRepository;

        public CategoriaService()
        {
            _categoriaGastoRepository = new CategoriaGastoRepository();  // Instanciamos directamente el acceso a datos
        }

        public List<CategoriaGasto> GetAllCategorias()
        {
            return _categoriaGastoRepository.GetAllCategorias();
        }

        public void AddCategoria(CategoriaGasto categoria)
        {
            _categoriaGastoRepository.InsertCategoria(categoria);
        }
    }
}
