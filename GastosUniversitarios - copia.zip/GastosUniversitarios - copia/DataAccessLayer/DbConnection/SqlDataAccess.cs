﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.DbConnection
{
    public class SqlDataAccess
    {
        private readonly String _ConnectionString;
        public SqlDataAccess()
        {
            _ConnectionString = "Data Source=ALEJANDRO\\SQLEXPRESS;Initial Catalog=ControlGastosUniversitarios;Integrated Security=True;Encrypt=False;Trust Server Certificate=True";
        }

        public SqlConnection GetconnectionBD()
        {
            return new SqlConnection(_ConnectionString);
        }
    }
}
