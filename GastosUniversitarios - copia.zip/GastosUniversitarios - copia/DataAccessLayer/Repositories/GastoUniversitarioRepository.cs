﻿using CommomLayer.Entities;
using DataAccessLayer.DbConnection;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Repositories
{
    public class GastoUniversitarioRepository
    {
        private readonly SqlDataAccess _dbAccess;

        public GastoUniversitarioRepository()
        {
            _dbAccess = new SqlDataAccess();
        }

        public DataTable GetAllGastos()
        {
            DataTable gastosTable = new DataTable();

            using(var connection = _dbAccess.GetconnectionBD())
            {
                string query = "SELECT  g.IdGastos, CONCAT(u.NombreUsuario, ' ' , u.Apellido) AS NombreCompleto, g.Monto, g.Descripcion, c.NombreCategoria,  g.Fecha FROM GastosUniversitarios g JOIN CategoriasGasto c ON g.IdCategoria = c.IdCategoria JOIN Usuarios u ON g.IdUsuario = u.IdUsuario";

                using(SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();

                    using(SqlDataReader reader = command.ExecuteReader())
                    {
                        gastosTable.Load(reader);
                    }
                }
            }

            return gastosTable;
        }

        public void InsertGasto(GastoUniversitario gasto)
        {
            using (var connection = _dbAccess.GetconnectionBD())
            {
                string query = @"INSERT INTO GastosUniversitarios(Monto, Descripcion, IdCategoria, IdUsuario)
                                 VALUES(@Monto, @Descripcion, @IdCategoria, @IdUsuario)";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Monto", gasto.Monto);
                command.Parameters.AddWithValue("@Descripcion", gasto.Descripcion);
                command.Parameters.AddWithValue("@IdCategoria", gasto.IdCategoria);
                command.Parameters.AddWithValue("@IdUsuario", gasto.IdUsuario);

                connection.Open();
                command.ExecuteNonQuery();

            }
        }

        public void UpdateGasto(GastoUniversitario gasto)
        {
            using (var connection = _dbAccess.GetconnectionBD())
            {
                string query = @"UPDATE GastosUniversitarios SET " +
                                "Fecha = @Fecha," +
                                "Monto = @Monto," +
                                "Descripcion = @Descripcion," +
                                "IdCategoria = @IdCategoria," +
                                "IdUsuario = @IdUsuario " +
                                "WHERE IdGastos = @IdGastos";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Monto", gasto.Monto);
                command.Parameters.AddWithValue("@Fecha", gasto.Fecha);
                command.Parameters.AddWithValue("@Descripcion", gasto.Descripcion);
                command.Parameters.AddWithValue("@IdCategoria", gasto.IdCategoria);
                command.Parameters.AddWithValue("@IdUsuario", gasto.IdUsuario);
                command.Parameters.AddWithValue("@IdGastos", gasto.IdGasto);


                connection.Open();
                command.ExecuteNonQuery();
            }
        }

        public void DeleteGasto(int id)
        {
            using (var connection = _dbAccess.GetconnectionBD())
            {
                connection.Open();
                var query = "DELETE FROM GastosUniversitarios WHERE IdGastos = @IdGastos";
                var command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@IdGastos", id);
                command.ExecuteNonQuery();
            }
        }
    }
}
