﻿using CommomLayer.Entities;
using DataAccessLayer.DbConnection;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer.Repositories
{
    public class CategoriaGastoRepository
    {
        private readonly SqlDataAccess _dbAccess;
        public CategoriaGastoRepository()
        {
            _dbAccess = new SqlDataAccess();
        }

        public List<CategoriaGasto> GetAllCategorias()
        {
            using (var connection = _dbAccess.GetconnectionBD())
            {
                connection.Open();
                var query = "SELECT * FROM CategoriasGasto";
                var command = new SqlCommand(query, connection);
                var reader = command.ExecuteReader();
                var categorias = new List<CategoriaGasto>();

                while (reader.Read())
                {
                    categorias.Add(new CategoriaGasto
                    {
                        IdCategoria = (int)reader["IdCategoria"],
                        NombreCategoria = reader["NombreCategoria"].ToString()
                    });
                }
                return categorias;
            }
        }
        public void InsertCategoria(CategoriaGasto categoria)
        {
            using (var Connection = _dbAccess.GetconnectionBD())
            {
                string query = @"INSERT INTO CategoriasGasto(NombreCategoria)
                                VALUES (@NombreCategoria)";

                SqlCommand command = new SqlCommand(query, Connection);

                command.Parameters.AddWithValue("@NombreCategoria", categoria.NombreCategoria);

                Connection.Open();
                command.ExecuteNonQuery();
            }
        }

    }
}
